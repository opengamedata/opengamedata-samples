## Data Logging Info:
See https://github.com/fielddaylab/waves/blob/master/README.md

Wave data is organized into levels, where each level is a distinct puzzle in the game.

